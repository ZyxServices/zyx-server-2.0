package com.zyx.service.coin;

import com.zyx.entity.coin.CoinLog;
import com.zyx.service.BaseService;

/**
 * Created by MrDeng on 2016/10/31.
 */
public interface CoinLogService extends BaseService<CoinLog> {
}
