package com.zyx.utils;

public class TimeAreaUtil {
	public static String TIME_AREA_START = "start";
	public static String TIME_AREA_END = "end";

}
